#!/bin/bash
# Script rápido para compilação

make clean && make build && echo "Compilação concluída com sucesso!"
